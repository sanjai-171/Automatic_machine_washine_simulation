/* 
 * File:   main.h
 * Author: sanja
 *
 * Created on 10 October, 2021, 7:56 PM
 */

#ifndef MAIN_H
#define	MAIN_H



#include"clcd.h"
#include"digital_keypad.h"

#define BLOCK 0xFF
#define WASHING_PROGRAM_DISPLAY 0x01
#define WATER_LEVEL 0x02

#define WASHING_PROGRAM_DISPLAY_RESET 0x10
#define WATER_LEVEL_RESET 0x11
#define RESET_NOTHING 0x00


void power_on_screen(void);
void clcd_write(unsigned char byte, unsigned char mode);
void clear_screen(void);
void washing_programs_display(unsigned char key);
void water_level_display(unsigned char key);

#endif	/* MAIN_H */

